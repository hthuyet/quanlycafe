(($) => {
  "use strict";
  $.fn.treeMultiselect = require('./main');
})(jQuery);
